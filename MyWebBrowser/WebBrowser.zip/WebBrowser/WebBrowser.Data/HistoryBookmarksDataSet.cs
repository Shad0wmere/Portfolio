﻿namespace WebBrowser.Data
{


    partial class HistoryBookmarksDataSet
    {
    }
}
