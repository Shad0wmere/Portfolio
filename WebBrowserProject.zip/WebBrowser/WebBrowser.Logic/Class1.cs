﻿namespace WebBrowser.Logic
{
    public class Class1
    {
    }
}
