import java.util.ArrayList;
import java.sql.Connection;
import java.io.BufferedReader;
import java.sql.DriverManager;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

  /**
   * Inserts2.java.
   * @author Matt Anderson.
   * @version 10/05/2021.
   */

/**
 * Creates class Inserts2.
 */

public class Inserts2 {
	public static void main(String[] args) {
		try {
			// Connection connection =
			// DriverManager.getConnection("jdbc:sqlite:C://sqlite3/Hospital1.db");
			
			displayTable("SELECT * FROM Person", 12);
			System.out.println("DONE DISPLAYING person\n\n");
			
			// executeSQL("DELETE FROM doctor_list", connection);

			displayTable("SELECT * FROM doctor_list", 2);
			System.out.println("DONE DISPLAYING doctor_list\n\n");
			// executeSQL("DELETE FROM treatment", connection);
			
			displayTable("SELECT * FROM treatment", 5);
			System.out.println("DONE DISPLAYING Treatment\n\n");

			menu();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	private static void importAll() {
		importPerson();
		importDoctor();
		importTreatment();
	}
	public static void menu() {
		int select = 0;
		boolean stop = false;

		try {
			
			System.out.println("Load driver success");
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

			while (!stop) {
				System.out.print("\n\nPlease choose an option: \n");
				System.out.print("1.   List occupied rooms with patient name & admitted date.\n");
				System.out.print("2.   List unoccupied rooms.\n");
				System.out.print("3.   List of all rooms.\n");
				System.out.print("4.   List all patients.\n");
				System.out.print("5.   List all patients currently admitted.\n");
				System.out.print("6.   List all patients discharged in a date range.\n");
            System.out.print("7.   List all patients admitted in a date range.\n");
            System.out.print("8.   List all admissions with diagnosis for a patient.\n");
            System.out.print("9.   List all treatments for a patient.\n");
            System.out.print("10.   List patients admitted from 30 days of their discharge.\n");
            System.out.print("11.   List total admissions, average duration, longest/shortest/average span between admissions.\n");
            System.out.print("12.   List diagnoses in descending order.\n");
            System.out.print("13.   List diagnoses in descending order for hospital patients.\n");
            System.out.print("14.   List treatments performed in descending order.\n");
            System.out.print("15.   List diagnoses with most admitted patients in ascending order.\n");
            System.out.print("16.   List doctor name and patient name for treatment ordered.\n");
            System.out.print("17.   List all staff in hospital in ascending order of last name.\n");
            System.out.print("18.   List primary doctors of patients admitted 4 times in 12 months.\n");
            System.out.print("19.   List all diagnoses for a doctor in descending order of occurence.\n");
            System.out.print("20.   List all treatments ordered by a doctor in descending order of occurence.\n");
            System.out.print("21.   List staff who participated in treatment of every patient admitted.\n");
				System.out.print("22.  Quit\n>> ");

				boolean cond = true;
				while (cond) {
					try {
						select = Integer.parseInt(in.readLine());
						if (select >= 1 && select <= 22)  {
							cond = false;
						} else {
							System.out.println("Please enter an available option!");
						}
					} catch (NumberFormatException e) {
						System.out.println("Your input must contain valid integers only! Try again: ");
					}
				}

				switch (select) {
				case 1:
					    occupiedRooms();
					    break;
				case 2:
					    emptyRooms();
					    break;
				case 3:
					    allRooms();
					    break;
				case 4:
					    allPatients();
					    break;
				case 5:
					    allAdmitted();
					    break;				
				case 6: allDischarged(); 
                   break;				 
            case 7:
					    totalAdmitted();
					    break;
            case 8:
					    patientAdmission();
					    break;  
            case 9:
					    allTreatments();
					    break;
            case 10:
					    last30Days();
					    break;
            case 11:
					    allAverages();
					    break;
            case 12:
					    descDiag();
					    break;
            case 13:
					    descDiag2();
					    break;
            case 14:
					    descTreatments();
					    break;
            case 15:
					    mostDiagnosed();
					    break;
            case 16:
					    whoOrdered();
					    break;
            case 17:
					    ascendingStaff();
					    break;
            case 18:
					    highAdmitDoctors();
					    break;
            case 19:
					    doctorDiagnosisHistory();
					    break;
            case 20:
					    doctorTreatHistory();
					    break;
            case 21:
					     superstarStaff();
					     break;            
            case 22:
					     stop = true;
				}
			}

			System.out.println("\n Bye!\n\n");
			System.exit(0);
		} catch (IOException e) {
			System.out.println("IO Exception!");
			
		}
	}

	

	public static int importPerson() {
		Connection connection = Database.getConnection();
		try {

			connection.createStatement().executeUpdate("PRAGMA foreign_keys = ON;");

			displayPersons();

			/* SQL insert for database table. */

			String query = "INSERT INTO person (type , pfirstName ,plastName , rNumber , EmergencyContactName  ,"
					+ "	  EmergencyContactNumber  ,InsurancePolicyNumber  ,InsurancePolicyCompany ,LastNameOfDoctor ,InitialDiagnosis ,"
					+ "	  admittedTime ,dischargeTime) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

			/* Prepare statement. */

			PreparedStatement ps = connection.prepareStatement(query);

			/* Get data from Person.txt. */

			ArrayList<Person> hospitalList = getHospitalListData("C://sqlite3/Person.txt");

			/* Insert hospitalList into the database. */

			int i = 0;
 
			for (Person person : hospitalList) {
            if (!matchPatient(person))
            {
				ps.setString(1, person.getType());
				ps.setString(2, person.getFirstname());
				ps.setString(3, person.getLastname());
				ps.setString(4, person.getRoomnumber());
				ps.setString(5, person.getEmergencyContactName());
				ps.setString(6, person.getEmergencyContactNumber());
				ps.setString(7, person.getInsurancePolicyNumber());
				ps.setString(8, person.getInsurancePolicyCompany());
				ps.setString(9, person.getLastNameOfDoctor());
				ps.setString(10, person.getInitialDiagnosis());
				ps.setString(11, person.getDateOfArrival());
				ps.setString(12, person.getDischargeDate());
				ps.executeUpdate();
				++i;
            }
				System.out.println("Insert the record:" + (i + 1));
			}
			ps.close();
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		} 

	}
   
   public static boolean matchPatient (Person person)
	{
	
		try {
			String query = String.format("SELECT * FROM patient WHERE pLastName = '%s' AND pFirstName ='%'",
					person.getLastname(), person.getFirstname());
			ResultSet rs = Database.getResultSet(query);
			if (rs!=null && rs.next())
			{
				// found a match.
				return true;
			}else {
				return false;
			}
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			Database.close();
		}
	}

	public static int importDoctor() {
		Connection connection = Database.getConnection();

		ArrayList<Doctor> doctorList = getDoctorListData("C://sqlite3/AdditionalDoctor.txt");
		try {
			/* Insert doctor_list.txt into the database. */
			String query = "INSERT INTO doctor_list VALUES (?, ?)";
			PreparedStatement ps = connection.prepareStatement(query);
			int i = 0;
			for (Doctor doctor : doctorList) {
				ps.setString(1, doctor.getPatientLastname());
				ps.setString(2, doctor.getDoctorLastname());
				ps.executeUpdate();
				System.out.println("Insert the record:" + (i + 1));
			}
			ps.close();

			return i;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}finally {
			Database.close();
		}
	}

	public static int importTreatment() {

		ArrayList<Treatment> treatmentList = getTreatmentListData("C://sqlite3/Treatment.txt");
		Connection connection = Database.getConnection();
		try {
			/* Insert Treatment.txt into the database. */
			String query = "INSERT INTO Treatment VALUES (?, ?,?,?,?)";
			PreparedStatement ps = connection.prepareStatement(query);
			int i = 0;
			for (Treatment treatment : treatmentList) {

				ps.setString(1, treatment.getPatientLastName());
				ps.setString(2, treatment.getEmployeeLastName());
				ps.setString(3, treatment.getTreatmentType());
				ps.setString(4, treatment.getProcedureName());
				ps.setString(5, treatment.getTimeStamp());
				ps.executeUpdate();
				System.out.println("Insert the record:" + (i + 1));
			}
			ps.close();
			return i;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public static void displayPersons() {
		
		try {
			ResultSet rs =Database.getResultSet("SELECT * FROM Person");
			if (rs==null ||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3));
			}while (rs.next());
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	}

	public static void displayTable(String query, int colCount) {
		try {
			ResultSet rs = Database.getResultSet(query);
			if (rs==null ||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				for (int i = 0; i < colCount; i++) {
					System.out.printf("%s - ", rs.getString(i + 1));
				}
				System.out.println("");

			}while (rs.next());
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	}

	public static ArrayList<Treatment> getTreatmentListData(String filePath) {

		FileInputStream finputsr = null;
		InputStreamReader istreamr = null;
		BufferedReader buffReader = null;
		ArrayList<Treatment> listResult = new ArrayList<Treatment>();

		try {
			finputsr = new FileInputStream(filePath);
			istreamr = new InputStreamReader(finputsr);
			buffReader = new BufferedReader(istreamr);

			String line = null;

			String[] strList = null;

			while (true) {

				line = buffReader.readLine();

				if (line == null) {

					break;

				} else {

					strList = line.split(",");

					Treatment treatment = new Treatment(strList[0], strList[1], strList[2], strList[3], strList[4]);
					listResult.add(treatment);

				}

			}
			return listResult;

		} catch (Exception e) {

			System.out.println("Read file error");
			e.printStackTrace();

		} finally {

			try {

				buffReader.close();
				istreamr.close();
				finputsr.close();

			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		return listResult;
	}

	public static ArrayList<Doctor> getDoctorListData(String filePath) {
		FileInputStream finputsr = null;
		InputStreamReader istreamr = null;
		BufferedReader buffReader = null;
		ArrayList<Doctor> listResult = new ArrayList<Doctor>();

		try {

			finputsr = new FileInputStream(filePath);
			istreamr = new InputStreamReader(finputsr);
			buffReader = new BufferedReader(istreamr);

			String line = null;

			String[] strList = null;

			while (true) {
				line = buffReader.readLine();
				if (line == null) {
					break;
				} else {
					strList = line.split(",");
					Doctor doctor = new Doctor(strList[0], strList[1]);
					listResult.add(doctor);
				}

			}
			return listResult;

		} catch (Exception e) {

			System.out.println("Read file error");
			e.printStackTrace();
		} finally {
			try {
				buffReader.close();
				istreamr.close();
				finputsr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		return listResult;
	}

	private static String getValueAt(String[] arr, int index, String alt) {
		if (arr.length > index) {
			return arr[index];
		} else {
			return alt;
		}
	}

	private static String[] padArray(String[] arr, int size, String defaultValue) {
		String[] retArr = new String[size];
		for (int i = 0; i < size; i++) {
			retArr[i] = defaultValue;
		}

		for (int i = 0; i < arr.length; i++) {
			retArr[i] = arr[i];
		}
		return retArr;
	}

	public static ArrayList<Person> getHospitalListData(String filePath) {

		FileInputStream finputsr = null;
		InputStreamReader istreamr = null;
		BufferedReader buffReader = null;
		ArrayList<Person> listResult = new ArrayList<Person>();

		try {

			finputsr = new FileInputStream(filePath);
			istreamr = new InputStreamReader(finputsr);
			buffReader = new BufferedReader(istreamr);
			String line = null;
			String[] strList = null;

			while (true) {

				line = buffReader.readLine();
				if (line == null) {
					break;
				} else {

					strList = padArray(line.split(","), 12, "");
					Person person = new Person(strList[0], strList[1], strList[2], strList[3], strList[4], strList[5],
							strList[6], strList[7], strList[8], strList[9], strList[10], strList[11]);
					listResult.add(person);
				}

			}
			return listResult;
		} catch (Exception e) {

			System.out.println("Read file error");
			e.printStackTrace();

		} finally {

			try {
				buffReader.close();
				istreamr.close();
				finputsr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		return listResult;
	}

   // #1 
	public static void occupiedRooms() {

		try {
			ResultSet rs =Database.getResultSet(
					"SELECT rNumber, pfirstName, plastName, admittedTime FROM Patient WHERE dischargedTime IS NULL");
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}

   // #2
	public static void emptyRooms()  {

		try {
			ResultSet rs = Database.getResultSet("SELECT rNumber AS Room_Numbers FROM Rooms WHERE patientId is NULL");
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}

   // #3
	public static void allRooms() {
		try {
			ResultSet rs = Database.getResultSet("SELECT rNumber, pfirstName, plastName, admittedTime FROM Patient WHERE dischargedTime IS NULL");
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}

   // #4
	public static void allPatients()  {
		try {
			ResultSet rs =Database.getResultSet("SELECT * FROM Patient");
			
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}

   // #5
	public static void allAdmitted() {
		try {	
			ResultSet rs =Database.getResultSet("SELECT admittedPatients.patientId AS patientID, admittedPatients.pfirstName,"
					+ "admittedPatients.plastName" + "FROM Patient pat"
					+ "JOIN (SELECT pat.patientId, pat.pfirstName, pat.plastName"
					+ "FROM Patient pat LEFT JOIN Discharge disch ON pat.patientId = disch.patientId WHERE"
					+ "disch.dischargedTime IS NULL) admittedPatients ON pat.patientId = admittedPatients.patientId");
			if (rs==null||!rs.next())
			{
				System.out.println("No Data found!");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}
   


	 // #6
	 public static void allDischarged() {
    try {
    String date1 = prompt("Enter From Date: (for example: 2020/08/14)");
	 String date2 = prompt("Enter To Date: (for example: 2020/08/14)");
	 
	 ResultSet rs =Database.getResultSet("SELECT patientId, pfirstName, plastName"
	   + "FROM Patient" + "INNER JOIN Discharge USING (plastName)"
	   + "WHERE dischargedTime BETWEEN " + date1 + date2 + " "); 
    if (rs==null||!rs.next())
    {
	    System.out.println ("No Data found");
		 return;
	 }
	 do {
			System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
		  }while (rs.next());
	   } catch (Exception e) {
		System.out.println("Read file error");
		e.printStackTrace();

		} 
	}

				 

      // #7
      public static void totalAdmitted()  {
		try {
         String date1 = prompt("Enter From Date: (for example: 2020/08/14)");
			String date2 = prompt("Enter To Date: (for example: 2020/08/14)");
      
			ResultSet rs =Database.getResultSet("SELECT patientId, pfirstName, plastName "
                      + "FROM Patient USING (plastName) WHERE admittedTime BETWEEN '" + date1 + "' AND '" + date2 + "'");			
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();

		} 
	}
   
      // #8 
   	public static void patientAdmission()  {
		try {
         String name = prompt("Enter patient's last name: ");
			ResultSet rs =Database.getResultSet("SELECT * FROM Triage WHERE plastName = '" + name + "'");
			
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}  
   
      // #9
      public static void allTreatments()  {
		try {
			 String query = "SELECT allTreatments.treatmentId AS treatmentId, allTreatments.treatType AS treatment_name "
                   + "FROM Triage AS Tri JOIN (SELECT t.treatmentId, t.name, treated.patientId "
                   + "FROM Treatment AS t JOIN (SELECT p.patientId, tri.treatmentId "
                   + "FROM Patient AS p JOIN Provides AS prov ON p.patientId = prov.patientId "
                   + "ORDER BY prov.timeProvided ASC) treated ON t.treatmentId = treated.treatmentId "
                   + "WHERE treated.patientId = searchedPatient) allPatientTreatments "
                   + "ON allPatientTreatments.patientId = tri.patientId"
                   + "GROUP BY tri.admittedTime"
                   + "ORDER BY tri.admittedTime DESC";
         ResultSet rs = Database.getResultSet(query);
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}
   
      // #10
      public static void last30Days()  {
		try {
			ResultSet rs =Database.getResultSet("SELECT Pat.patientId AS patientId, pfirstName || ' ' || plastName AS Patient_name, diagnosisname "
                                            + "AS diagnosis, pd.staffId AS Doctor "
                                            + "FROM ((SELECT tri.rNumber, tri.pfirstName, tri.plastName, tri.admittedTime, "
                                            + "tri.patientId,tri.initialDiagId,pd.staffId "
                                            + "FROM (Triage AS tri JOIN PrimaryDoctor AS pd USING (staffId) JOIN Rooms USING (patientId)) JOIN "
                                            + "Patient USING (patientId) "
                                            + "WHERE tri.admittedTime > (SELECT MAX (dischargedTime) FROM Discharge as disch WHERE tri.patientId = "
                                            + "disch.patientId)) AS Pat "
                                            + "JOIN Discharge AS disch ON (disch.patientId = Pat.patientId)) JOIN Diagnosis USING (initialDiagId) "
                                            + "GROUP BY Pat.patientId HAVING (MAX(admittedTime) � MAX(dischargedTime)) <= 30");
			
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {

			System.out.println("Read file error");
			e.printStackTrace();
		}
	}
   
      // #11
      public static void allAverages()  {
		try {
			ResultSet rs =Database.getResultSet("SELECT X.patientId, X.TotalAdmissions, X.AvgDuration, Y.MaxedSpan, Y.MinimumSpan, Y.AVGS "
                                     + "FROM (SELECT tri.patientId, "
                                     + "MAX(JULIANDAY(tri.admittedTime) � JULIANDAY(tri.date)) MaxedSpan, "
                                     + "MIN(JULIANDAY(tri.admittedTime) � JULIANDAY(tri.date)) MinimumSpan, "
                                     + "AVG(JULIANDAY(tri.admittedTime) � JULIANDAY(tri.date)) AVGS "
                                     + "FROM ((Patient JOIN Triage USING (patientId)) JOIN Discharge USING (patientId)) AS tri "
                                     + "WHERE (JULIANDAY(tri.admittedTime) � JULIANDAY(tri.date)) IN "
                                     + "(SELECT JULIANDAY(more.admittedTime) � JULIANDAY(more.date)) "
                                     + "FROM ((Patient JOIN Triage USING (patientId)) JOIN Discharge USING (patientId)) as more "
                                     + "WHERE tri.patientId = more.patientId AND (JULIANDAY(more.admittedTime) � JULIANDAY(tri.date)) > 0) "
                                     + "GROUP BY tri.patientId AS Y, (SELECT patientId, COUNT (tri.admittedTime) AS TotalAdmissions, "
                                     + "AVG (JULIANDAY(tri.date) � JULIANDAY(tri.admittedTime)) AS AvgDuration "
                                     + "FROM ((Patient JOIN Triage USING (patientId)) JOIN Discharge USING (patientId) as tri "
                                     + "GROUP BY tri.patientId ) AS X WHERE Y.patientId = X.patientId))");
			
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}
   
      // #12
      public static void descDiag()  {
		try {
			ResultSet rs =Database.getResultSet("SELECT tri.initialDiagId, diagnosisname, COUNT(diagnosis) "
                                           + "FROM Triage AS tri INNER JOIN Diagnosis AS diag ON(tri.diagnosis = diag.diagnosisname) "
                                           + "GROUP BY diagnosisname "
                                           + "ORDER BY Count(diagnosis) DESC");
			
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {

			System.out.println("Read file error");
			e.printStackTrace();
		}
	}
   
      // #13
      public static void descDiag2()  {
		try {
			ResultSet rs =Database.getResultSet("SELECT tri.initialDiagId, diagnosisname, COUNT(diagnosis) "
                                       + "FROM Triage AS tri INNER JOIN Diagnosis AS diag ON(tri.diagnosis = diag.diagnosisname) "
                                       + "GROUP BY diagnosisname "
                                       + "ORDER BY Count(diagnosis) DESC");
			
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {

			System.out.println("Read file error");
			e.printStackTrace();
		}
	}
   
      // #14
      public static void descTreatments()  {
		try {
			String query = "SELECT treatmentId, ord.procedure, COUNT(t.procedure) FROM Treatment AS t "
                                           + "INNER JOIN Ordered as ord ON(t.procedure = ord.procedure) "
                                           + "GROUP BY ord.procedure "
                                           + "ORDER BY Count(t.procedure) DESC";
			ResultSet rs = Database.getResultSet(query);
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {

			System.out.println("Read file error");
			e.printStackTrace();
		}
	}
   
      // #15
      public static void mostDiagnosed()  {
		try {
			ResultSet rs =Database.getResultSet("SELECT p.patientId, diag.initialDiagId, diag.diagnosisname "
                                        + "FROM Diagnosis AS diag "
                                        + "JOIN Patient AS p ON diag.patientId = p.patientId "
                                        + "JOIN Triage AS tri ON p.patientId = tri.patientId "
                                        + "GROUP BY p.patientId "
                                        + "HAVING COUNT(tri.admittedTime) = (SELECT MAX(numAdmitted) "
                                        + "FROM (SELECT COUNT(admittedTime)) numAdmitted "
                                        + "FROM Triage GROUP BY patientId)) "
                                        + "ORDER BY tri.admittedTime DESC");
			
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}
   
      // #16
      public static void whoOrdered()  {
		   try {
         String desiredTreatment = prompt("Enter name of treatment: ");
			ResultSet rs =Database.getResultSet("FROM Provides AS prov JOIN Doctor AS d ON prov.careproviderId = d.careproviderId "
                                           + "JOIN Patient AS p ON prov.patientId = p.patientId "
                                           + "WHERE prov.treatmentId = desiredTreatment AND p.patientId = searchedPatient");
			
			   if (rs==null||!rs.next())
			   {
				   System.out.println ("No Data found");
				   return;
			   }
			   do {
				   System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			   }while (rs.next());
		   } catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		   }
	   }
   
      // #17
      public static void ascendingStaff()  {
		try {
			ResultSet rs =Database.getResultSet("SELECT e.staffId, e.emp_lastName, e.emp_firstName, 'Admin' AS category "
                           + "FROM Employee AS e JOIN Admins AS a ON e.staffId = a.staffId "
                           + "UNION " 
                           + "SELECT e.staffId, e.emp_lastName, e.emp_firstName, 'Tech' AS category "
                           + "FROM Employee AS e JOIN Techs AS t ON e.staffId = t.staffId "
                           + "UNION "
                           + "SELECT e.staffId, e.emp_lastName, e.emp_firstName, 'Doctor' AS category "
                           + "FROM Employee AS e JOIN Doctors AS d ON e.staffId = d.staffId "
                           + "UNION "
                           + "SELECT e.staffId, e.emp_lastName, e.emp_firstName, 'Nurse' AS category "
                           + "FROM Employee AS e JOIN Nurses AS n ON e.staffId = n.staffId "
                           + "ORDER BY e.emp_lastName");
			
			if (rs==null||!rs.next())
			{
				System.out.println ("No Data found");
				return;
			}
			do {
				System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}while (rs.next());
		} catch (Exception e) {
			System.out.println("Read file error");
			e.printStackTrace();
		}
	}
   
      // #18
      public static void highAdmitDoctors()  {
		   try {
			      ResultSet rs =Database.getResultSet("SELECT d.staffId FROM (Patient AS p "
                           + "JOIN Triage AS tri USING (patientId)) "
                           + "JOIN Doctors d ON d.staffId = tri.staffId GROUP BY patientId "
                           + "HAVING (SELECT COUNT(tri.admittedTime) FROM Discharge AS disch "
                           + "WHERE tri.patientId = disch.patientId "
                           + "AND ((julianday(disch.dischargedTime) � julianday(tri.admittedTime)) <= 365)) >= 4 "
                           + "ORDER BY d.staffId");
			   
			      if (rs==null||!rs.next())
			      {
				         System.out.println ("No Data found");
				         return;
			      }
			      do {
				      System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			      }while (rs.next());
		   } catch (Exception e) {
			   System.out.println("Read file error");
			   e.printStackTrace();
		   }
	   }
   
   	public static String prompt(String prompt) {
		      BufferedReader reader = null;
		      try {
			         reader = new BufferedReader(new InputStreamReader(System.in));
			         System.out.print(prompt);
			         // Reading data using readLine.
			         String text = reader.readLine();
			         return text;
		      } catch (Exception ex) {
			            return null;
		      }finally {
			            try {
				               reader.close();
			            }catch (Exception e) {}
		      }
	   }
   
      // #19
      public static void doctorDiagnosisHistory()  {
		   try {
            String name = prompt("Enter Doctor's last name: ");
			   ResultSet rs =Database.getResultSet("SELECT DISTINCT diagnosis, COUNT(diagnosis) "
					+ "FROM Triage WHERE emp_lastName = '" + name + "' ORDER BY COUNT(diagnosis) DESC");
			
			   if (rs==null||!rs.next())
			   {
				      System.out.println ("No Data found");
				      return;
			   }
			   do {
				      System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			   }while (rs.next());
		   } catch (Exception e) {
			      System.out.println("Read file error");
			      e.printStackTrace();
		   }
	   }
   
      // #20
      public static void doctorTreatHistory()  {
		   try {
               String name = prompt("Enter Doctor's last name: ");
			      ResultSet rs =Database.getResultSet("SELECT DISTINCT procedure, COUNT(procedure) " + "FROM Treatment "
                                           + "WHERE emp_lastName = '" + name + "' ORDER BY COUNT(procedure) DESC");
			
			      if (rs==null||!rs.next())
			      {
				         System.out.println ("No Data found");
				         return;
			      }
			      do {
				         System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			      }while (rs.next());
		   } catch (Exception e) {
			      System.out.println("Read file error");
			      e.printStackTrace();
		   }
	   }
   
      // #21
      public static void superstarStaff()  {
		   try {
			   ResultSet rs =Database.getResultSet("SELECT DL.plastName, DL.emp_lastName "
                                    + "FROM doctor_list AS DL "
                                    + "INNER JOIN Triage AS tri ON(DL.plastName = tri.plastName) "
                                    + "WHERE tri.dischargedate IS NULL");
			
			   if (rs==null||!rs.next()) {
				      System.out.println ("No Data found");
				      return;
			   }
			   do {
				      System.out.printf("%s - %s - %s\n", rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
			   }while (rs.next());
		   } catch (Exception e) {
			      System.out.println("Read file error");
			      e.printStackTrace();
		   }
	   }
   
} 
   

class Database {
	   static Connection connection = null;

	   public static Connection getConnection() {
		      try {
			      if (connection != null && !connection.isClosed())
				      return connection;

			      Class.forName("org.sqlite.JDBC");
			      System.out.println("Load driver success");

			      Connection connection = DriverManager.getConnection("jdbc:sqlite:C://sqlite3/Hospital1.db");
			      return connection;
		      } catch (Exception e) {
			   e.printStackTrace();
			   return null;
		      }
	}

	public static void execute(String query) throws Exception {
		   try {
			      PreparedStatement ps = getConnection().prepareStatement(query);
			      ps.execute();
		   } catch (Exception e) {
			         e.printStackTrace();
			         return;
		   } finally {
			      close();
		   }
	}
   
	public static ResultSet getResultSet(String query)  {
		   try {
			      Connection conn = Database.getConnection();
               PreparedStatement ps = conn.prepareStatement(query);
			      return ps.executeQuery();
			
		   } catch (Exception e) {
			         System.out.println (query);
			         e.printStackTrace();
			         return null;
		   }
	}
   
	public static void close() {
		try {
			      connection.close();
			      connection = null;
		} catch (Exception e) {
			      e.printStackTrace();
			      return;
		}
	}
}