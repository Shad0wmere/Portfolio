
  
  /**
   * Doctor.java.
   * @author Matt Anderson.
   * @version 09/13/2021.
   */

   /**
   * Creates class Doctor.
   */

public class Doctor {
   String patientLastname;
	String doctorLastname;

   /* getters and setters. */

   /** Returns this patient's last name.
   * gets patient's last name.
   * @return patientLastname as string.
   */
	public String getPatientLastname() {
		return patientLastname;
	}
  /**
  * sets this.patientLastname to patientLastname.
  * @param patientLastname as string.
  */
	public void setPatientLastname(String patientLastname) {
		this.patientLastname = patientLastname;
	}
	  	  
	public Doctor(String patientLastname, String doctorLastname) {
		super();
      this.patientLastname = patientLastname;
		this.doctorLastname = doctorLastname;
	}
     
     /** Returns this doctor's last name. 
     * gets Doctor's last name.
     * @return doctorLastname as string.
     */
   public String getDoctorLastname() {
      return doctorLastname;
	}
  /**
  * sets this.doctorLastname to doctorLastname.
  * @param doctorLastname as string.
  */
	public void setDoctorLastname(String doctorLastname) {
		this.doctorLastname = doctorLastname;
	}

}
