  
  /**
   * Person.java.
   * @author Matt Anderson.
   * @version 09/13/2021.
   */

   /**
   * Creates class Person.
   */

public class Person {
	  String type;
	  String firstname;
	  String lastname;
	  String roomnumber;
	  String EmergencyContactName;
	  String EmergencyContactNumber;
	  String InsurancePolicyNumber;
	  String InsurancePolicyCompany;
	  String LastNameOfDoctor;
	  String InitialDiagnosis;
	  String DateOfArrival;
	  String DischargeDate;
     
	public Person(String type, String firstname, String lastname, String roomnumber, String emergencyContactName,
			String emergencyContactNumber, String insurancePolicyNumber, String insurancePolicyCompany,
			String lastNameOfDoctor, String initialDiagnosis, String dateOfArrival, String dischargeDate) {
		super();
		this.type = type;
		this.firstname = firstname;
		this.lastname = lastname;
		this.roomnumber = roomnumber;
		EmergencyContactName = emergencyContactName;
		EmergencyContactNumber = emergencyContactNumber;
		InsurancePolicyNumber = insurancePolicyNumber;
		InsurancePolicyCompany = insurancePolicyCompany;
		LastNameOfDoctor = lastNameOfDoctor;
		InitialDiagnosis = initialDiagnosis;
		DateOfArrival = dateOfArrival;
		DischargeDate = dischargeDate;
	}
   
   /* getters and setters. */

   /** Returns type.
   * gets type.
   * @return type as string.
   */
   
	public String getType() {
		return type;
	}
  /**
  * sets this.type to type.
  * @param type as string.
  */
	public void setType(String type) {
		this.type = type;
	}
   /** Returns firstname.
   * gets firstname.
   * @return firstname as string.
   */
	public String getFirstname() {
		return firstname;
	}
  /**
  * sets this.firstname to firstname.
  * @param firstname as string.
  */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
   /** Returns lastname.
   * gets lastname.
   * @return lastname as string.
   */
	public String getLastname() {
		return lastname;
	}
  /**
  * sets this.lastname to lastname.
  * @param lastname as string.
  */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
   /** Returns roomnumber.
   * gets roomnumber.
   * @return roomnumber as string.
   */
	public String getRoomnumber() {
		return roomnumber;
	}
  /**
  * sets this.roomnumber to roomnumber.
  * @param roomnumber as string.
  */
	public void setRoomnumber(String roomnumber) {
		this.roomnumber = roomnumber;
	}
   /** Returns EmergencyContactName.
   * gets EmergencyContactName.
   * @return EmergencyContactName as string.
   */
	public String getEmergencyContactName() {
		return EmergencyContactName;
	}
  /**
  * sets EmergencyContactName to emergencyContactName.
  * @param emergencyContactName as string.
  */
	public void setEmergencyContactName(String emergencyContactName) {
		EmergencyContactName = emergencyContactName;
	}
   /** Returns EmergencyContactNumber.
   * gets EmergencyContactNumber.
   * @return EmergencyContactNumber as string.
   */
	public String getEmergencyContactNumber() {
		return EmergencyContactNumber;
	}
  /**
  * sets EmergencyContactNumber to emergencyContactNumber.
  * @param emergencyContactNumber as string.
  */
	public void setEmergencyContactNumber(String emergencyContactNumber) {
		EmergencyContactNumber = emergencyContactNumber;
	}
   /** Returns InsurancePolicyNumber.
   * gets InsurancePolicyNumber.
   * @return InsurancePolicyNumber as string.
   */
	public String getInsurancePolicyNumber() {
		return InsurancePolicyNumber;
	}
  /**
  * sets InsurancePolicyNumber to insurancePolicyNumber.
  * @param insurancePolicyNumber as string.
  */
	public void setInsurancePolicyNumber(String insurancePolicyNumber) {
		InsurancePolicyNumber = insurancePolicyNumber;
	}
   /** Returns InsurancePolicyCompany.
   * gets InsurancePolicyCompany.
   * @return InsurancePolicyCompany as string.
   */
	public String getInsurancePolicyCompany() {
		return InsurancePolicyCompany;
	}
  /**
  * sets InsurancePolicyCompany to insurancePolicyCompany.
  * @param insurancePolicyCompany as string.
  */
	public void setInsurancePolicyCompany(String insurancePolicyCompany) {
		InsurancePolicyCompany = insurancePolicyCompany;
	}
   /** Returns LastNameOfDoctor.
   * gets LastNameOfDoctor.
   * @return LastNameOfDoctor as string.
   */
	public String getLastNameOfDoctor() {
		return LastNameOfDoctor;
	}
  /**
  * sets LastNameOfDoctor to lastNameOfDoctor.
  * @param lastNameOfDoctor as string.
  */
	public void setLastNameOfDoctor(String lastNameOfDoctor) {
		LastNameOfDoctor = lastNameOfDoctor;
	}
   /** Returns InitialDiagnosis.
   * gets InitialDiagnosis.
   * @return InitialDiagnosis as string.
   */
	public String getInitialDiagnosis() {
		return InitialDiagnosis;
	}
  /**
  * sets InitialDiagnosis to initialDiagnosis.
  * @param initialDiagnosis as string.
  */
	public void setInitialDiagnosis(String initialDiagnosis) {
		InitialDiagnosis = initialDiagnosis;
	}
   /** Returns DateOfArrival.
   * gets DateOfArrival.
   * @return DateOfArrival as string.
   */
	public String getDateOfArrival() {
		return DateOfArrival;
	}
  /**
  * sets DateOfArrival to dateOfArrival.
  * @param dateOfArrival as string.
  */
	public void setDateOfArrival(String dateOfArrival) {
		DateOfArrival = dateOfArrival;
	}
   /** Returns DischargeDate.
   * gets DischargeDate.
   * @return DischargeDate as string.
   */
	public String getDischargeDate() {
		return DischargeDate;
	}
  /**
  * sets DischargeDate to dischargeDate.
  * @param dischargeDate as string.
  */
	public void setDischargeDate(String dischargeDate) {
		DischargeDate = dischargeDate;
	}	  
	
}
