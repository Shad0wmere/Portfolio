  
  /**
   * Treatment.java.
   * @author Matt Anderson.
   * @version 09/13/2021.
   */
   
   /**
   * Creates class Treatment.
   */

public class Treatment {
	String patientLastName;
	String employeeLastName;
	String treatmentType;
	String procedureName;
	String timeStamp;
	public Treatment(String patientLastName, String employeeLastName, String treatmentType, String procedureName,
			String timeStamp) {
		super();
		this.patientLastName = patientLastName;
		this.employeeLastName = employeeLastName;
		this.treatmentType = treatmentType;
		this.procedureName = procedureName;
		this.timeStamp = timeStamp;
	}
   /* getters and setters. */
   
     /** Returns patientLastname. 
     * gets PatientLastName.
     * @return patientLastName as string.
     */
	public String getPatientLastName() {
		return patientLastName;
	}
  /**
  * sets this.patientLastname to patientLastname.
  * @param patientLastName as string.
  */
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
     /** Returns employeeLastname. 
     * gets EmployeeLastName.
     * @return employeeLastName as string.
     */
	public String getEmployeeLastName() {
		return employeeLastName;
	}
  /**
  * sets this.employeeLastname to employeeLastname.
  * @param employeeLastName as string.
  */
	public void setEmployeeLastName(String employeeLastName) {
		this.employeeLastName = employeeLastName;
	}
     /** Returns treatmentType. 
     * gets TreatmentType.
     * @return treatmentType as int.
     */
	public String getTreatmentType() {
		return treatmentType;
	}
  /**
  * sets this.treatmentType to treatmentType.
  * @param treatmentType as string.
  */
	public void setTreatmentType(String treatmentType) {
		this.treatmentType = treatmentType;
	}
     /** Returns procedureName. 
     * gets ProcedureName.
     * @return procedureName as string.
     */
	public String getProcedureName() {
		return procedureName;
	}
  /**
  * sets this.procedureName to procedureName.
  * @param procedureName as string.
  */
	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}
     /** Returns timeStamp. 
     * gets TimeStamp.
     * @return timeStamp as string.
     */
	public String getTimeStamp() {
		return timeStamp;
	}
  /**
  * sets this.timeStamp to timeStamp.
  * @param timeStamp as string.
  */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}	
	
}
